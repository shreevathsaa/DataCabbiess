# DataCabbies

### 7-December <br />

Fahad: Added CSVtoJSON folder. It contains python scripts to change uber, green, and yellow taxi csv data to json <br />
Shree: Added GUI file : It contains the python code for GUI framework, where we need to input values. <br />

### 8-December <br />

Ahmed <br />
mongoimport for cmd <br />
Run this command at the path of the json file <br />
"mongoimport path"/mongoimport --host localhost:27017 --db "database name" --collection "collection name" "json file name" <br />

General Script to change csv to json <br />
Add the csvfilename as a commandline argument 
The jsonfilename is an optional commandline argument <br />
Extension needed: pass the header names as commandline argument somehow <br />

### 9-December <br />
Shree: Added functions seperately for green and yellow data for Jan 2017:cleaning data - whole will be uploaded soon as class file. <br />

### 13-December <br />
Fahad: Python script which used to read CSV file and clean the dataset in order to reduce the size of file. <br />
      - Be patient, it takes time to read, remove and write the file. <br />
      - Don't  forget to update the list of column indexes<br />

### 20-December <br />
Ayah: Python script that has Simple_functions to return data of pickups on one day or on mondays for Jan, it is hard coded

### 20-December <br />
Shree : Uploaded try.iypnb file where I have tried to visualize the data set in the form of scatter plots with respect to the tip amount.
